package beans;

public class Exercise5_2{
	private String id;
	private String password;
	private String _id;
	private String _password;
	
	public Exercise5_2() {
		_id="admin";
		_password="1234";
	}
	
	public boolean checkUser() {
		if(id.equals(_id)&&password.equals(_password))
			return true;
		else return false;
	}
	public void setId(String id) {
		this.id=id;
	}
	public void setPassword(String password) {
		this.password=password;
	}
	public String getId() {
		return this.id;
	}
	public String getPassword() {
		return this.password;
	}

}